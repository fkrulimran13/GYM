<!DOCTYPE html>
<html>
<head>
  <title></title>
  <!-- Styles -->  
<style>
 body,html {
  height: 100%;
}

.bg {
background-image : url("bmi.jpg");
height : 100%;
background-position : center;
background-repeat : no-repeat;
background-size : cover;
}
div {
  border: 1px solid gray;
  padding: 8px;
}

h1 {
  text-shadow: 2px 2px brown;
}

p {
  text-indent: 50px;
  text-align: justify;
  letter-spacing: 3px;
}

a {
  text-decoration: none;
  color: #008CBA;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
</head>
<!-- background sistem-->
<body background="bmi.jpg">
<br>
  <ul>
    <li>
      <a href="login.php">Login</a>
    </li>
    <li>
      <a href="index.php">Home</a>
    </li>
    <li>
      <a href="signup.php">Sign Up</a>
    </li>
  </ul>
  <br>
<br>
<center>
  <!-- javascript for masa dan hari -->
<button type="button"
onclick="document.getElementById('demo').innerHTML = Date()">
Click me to display Date and Time.</button>

<p id="demo"></p>
</center>
<br>
  <h1><center><b>SELAMAT DATANG KE GYM "FITNESS"</b></center></h1>
<center>
<table border="1" cellpadding="0" cellspacing="4">

<pre>Username:<input type="text" id="username"></pre>
<pre>Password:<input type="text" id="password"></pre>
</table>
<center><form>
      <input type="button" onclick="window.location.href='index.php';" value="SUBMIT" />
      <input type="button" onclick="window.location.href='login.php';" value="RESET" />
    </form>
<br><br>
<!-- vid montage -->
<center><video width="345" height="200" controls autoplay>
  <source src="nike.mp4" type="video/mp4" >
    <source src="movie.ogg" type="video/ogg">
  Your browser does not support the video tag.
</video></center>
</center>
</body>
</html>
