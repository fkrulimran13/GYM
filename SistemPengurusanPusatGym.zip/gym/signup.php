<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
	<style>
 body,html {
  height: 100%;
}

.bg {
background-image : url("bmi.jpg");
height : 100%;
background-position : center;
background-repeat : no-repeat;
background-size : cover;
}
div {
  border: 1px solid gray;
  padding: 8px;
}

h1 {
  text-shadow: 2px 2px brown;
}

p {
  text-indent: 50px;
  text-align: justify;
  letter-spacing: 3px;
}

a {
  text-decoration: none;
  color: #008CBA;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
</head>
<body bgcolor="lightgrey">

	<center>

		<p><strong><center>BORANG MENAMBAH AHLI BARU</center></strong></p>
		<!-- jadual form -->
		<form id="form" name="form" method="post" action="proinsert_data_user.php">
			<table width="400" border="1">
				<tr>
					<th scope="col">Nama : </th>
					<th scope="col"><div align="left">
						<input type="text" name="nama_pelanggan" value="" size="50"/>
					</div></th>
				</tr>
				<tr>
					<th scope="col">Nombor Kad Pengenalan : (Tanpa -)</th>
					<th scope="col"><div align="left">
						<input type="text" name="no_ic" value="" size="12"/>
					</div></th>
				</tr>
				<tr>
					<th scope="col">Tempat Lahir :</th>
					<th scope="col"><div align="left"><select name="tempat_lahir">
						<option value="">Sila Pilih</option>
						<option value="Johor">Johor</option>
						<option value="Kedah">Kedah</option>
						<option value="Kelantan">Kelantan</option>
						<option value="Melaka">Melaka</option>
						<option value="Negeri Sembilan">Negeri Sembilan</option>
						<option value="Pahang">Pahang</option>
						<option value="Pulau Pinang">Pulau Pinang</option>
						<option value="Perak">Perak</option>
						<option value="Perlis">Perlis</option>
						<option value="Selangor">Selangor</option>
						<option value="Terengganu">Terengganu</option>
						<option value="Sabah">Sabah</option>
						<option value="Sarawak">Sarawak</option>
					</select></div>
					</th>
				</tr>
				<tr>
					<th scope="col">Jantina :</th>
					<th scope="col"><div align="left">
						<input type="radio" name="jantina" value="Lelaki">Lelaki<br>
						<input type="radio" name="jantina" value="Perempuan">Perempuan<br>
					</div></th>
				</tr>
			</table>
			<br>
			<center>
				<!-- submit menjadi ahli baru-->
				<button type="submit" value="Submit">Submit</button>
				<button type="reset" value="reset">Reset</button>
				<br>
			</center>
		</form>
		<br>
		<!-- pulang ke halaman home -->
		<button><a href="index.php" target="_top">Home</a></button><br>
		<br>

	</center>

</body>
</html>