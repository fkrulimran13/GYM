<?php

$server='localhost';
$username='root';
$password='';
$dbname='gym'; 

$conn=mysqli_connect("$server","$username","$password","$dbname");
//menghubungkan data ke pangkalan data 
?>