<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
<!--mencantikkan laman web -->
	<style>
 body,html {
  height: 100%;
}

.bg {
background-image : url("bmi.jpg");
height : 100%;
background-position : center;
background-repeat : no-repeat;
background-size : cover;
}
div {
  border: 1px solid gray;
  padding: 8px;
}

h1 {
  text-shadow: 2px 2px brown;
}

p {
  text-indent: 50px;
  text-align: justify;
  letter-spacing: 3px;
}

a {
  text-decoration: none;
  color: #008CBA;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
</head>
<body bgcolor="grey">

	<!--tulisan bergerak -->
	 <marquee><h1>SELAMAT DATANG KE GYM "FITNESS"</h1></marquee>
	 <br>
	 <!-- nav bar -->
  <ul>
    <li>
      <a href="login.php">Login</a>
    </li>
    <li>
      <a href="index.php">Home</a>
    </li>
    <li>
      <a href="signup.php">Sign Up</a>
    </li>
  </ul>
  <br>

  <center><img src="gym.jpg"></center>

</body>
</html>